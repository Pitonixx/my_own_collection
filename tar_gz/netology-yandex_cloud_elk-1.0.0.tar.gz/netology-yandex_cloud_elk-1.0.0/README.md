# Ansible Collection - netology.yandex_cloud_elk

Documentation for the collection.

### Коллекция Ansible с тестовой ролью, использующей тестовый модуль test_module.py, который создает файл на удаленном хосте по пути [path], с наполнением [content].